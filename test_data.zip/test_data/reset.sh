#! /bin/bash


sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1
sudo iptables -D OUTPUT 1

sudo iptables -L -n --line-number