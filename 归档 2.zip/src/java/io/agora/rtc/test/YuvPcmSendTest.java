package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import io.agora.rtc.AgoraAudioPcmDataSender;
import io.agora.rtc.AgoraLocalAudioTrack;
import io.agora.rtc.AgoraLocalVideoTrack;
import io.agora.rtc.AgoraMediaNodeFactory;
import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraService;
import io.agora.rtc.AgoraVideoFrameSender;
import io.agora.rtc.Constants;
import io.agora.rtc.ExternalVideoFrame;
import io.agora.rtc.GeneralTest;
import io.agora.rtc.RtcConnConfig;
import io.agora.rtc.VideoDimensions;
import io.agora.rtc.VideoEncoderConfig;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleCommon;
import io.agora.rtc.common.SampleLocalUserObserver;


public class YuvPcmSendTest extends AgoraTest {

    static {
        System.loadLibrary("mediautils");
    }

    // audio thread
    // send audio data every 10 ms;
    class PcmSender extends FileSender {
        private AgoraAudioPcmDataSender audioFrameSender;
        private static final int INTERVAL = 50; //ms
        private int channels;
        private int samplerate;
        private int bufferSize = 0;
        private byte[] buffer;
        public PcmSender(String filepath, AgoraAudioPcmDataSender sender,int channels,int samplerate){
            super(filepath, INTERVAL);
            audioFrameSender = sender;
            this.channels = channels;
            this.samplerate = samplerate;
            this.bufferSize = channels * samplerate * 2 * INTERVAL /1000;
            this.buffer = new byte[this.bufferSize];
        }

        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(data == null) return;
            audioFrameSender.send(data,(int)timestamp,sampleRate/(1000/INTERVAL),2,channels,samplerate);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            if(fos != null ){
                try {
                    int size = fos.read(buffer,0,bufferSize);
                    if( size <= 0){
                        reset();
                        return null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return buffer;
        }
    }

    class Yuv420Sender extends FileSender {
        private AgoraVideoFrameSender imageSender;
        private int height;
        private int width;
        private  byte[] buffer;
        private int bufferLen;
        public Yuv420Sender(String path, int interval, int height, int width, AgoraVideoFrameSender videoEncodedImageSender){
            super(path,interval);
            this.imageSender = videoEncodedImageSender;
            this.height = height;
            this.width = width;
            this.bufferLen = (int)(this.height*this.width*1.5);
            this.buffer = new byte[this.bufferLen];
        }
        private boolean writeData = false;
        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(!writeData){
                File file = new File("piece.yuv");
                FileOutputStream fos = null;
                try {
                    fos = new FileOutputStream(file);
                    fos.write(data);
                    fos.flush();
                    fos.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writeData = true;
            }
            if(data == null) return;
            ExternalVideoFrame externalVideoFrame = new ExternalVideoFrame();
            externalVideoFrame.setHeight(height);
            ByteBuffer buffer = ByteBuffer.allocateDirect(data.length);
            buffer.put(data);
            externalVideoFrame.setBuffer(buffer);
            externalVideoFrame.setRotation(0);
            externalVideoFrame.setFormat(Constants.EXTERNAL_VIDEO_FRAME_PIXEL_FORMAT_I420);
            externalVideoFrame.setStride(width);
            externalVideoFrame.setType(Constants.EXTERNAL_VIDEO_FRAME_BUFFER_TYPE_RAW_DATA);
            externalVideoFrame.setTimestamp(timestamp);
            imageSender.send(externalVideoFrame);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            if(fos == null)return null;
            try {
                int size = fos.read(this.buffer,0, bufferLen);
                if( size <= 0){
                    reset();
                }
            } catch (Exception e){
                e.printStackTrace();
            }
            return this.buffer;
        }

        @Override
        public void release() {
            super.release();
        }
    }
    // video thread
//    class SendVideoThread extends Thread {
//        private AgoraVideoEncodedImageSender videoH264FrameSender;
//
//        public SendVideoThread(AgoraVideoEncodedImageSender vfsender, boolean ef) {
//            videoH264FrameSender = vfsender;
//        }
//        public void sendOneH264Frame(int frameRate, , AgoraVideoEncodedImageSender veis) {
//            EncodedVideoFrameInfo videoEncodedFrameInfo;
//            videoEncodedFrameInfo.setRotation(0);
//            videoEncodedFrameInfo.setCodecType(2);
//            videoEncodedFrameInfo.setFramesPerSecond(frameRate);
//            //
//            videoEncodedFrameInfo.setFrameType();
//            veis.send(, , videoEncodedFrameInfo);
//        }
//        public void SampleSendAudioTask(AgoraVideoEncodedImageSender veis) {
//            while (!exitFlag) {
//                HelperH264FileParser h264FileParser = new HelperH264FileParser();
//                h264FileParser.initialize();
//                HelperH264Frame hframe = h264FileParser.getH264Frame();
//                if (hframe) {
//                    sendOneH264Frame((veis));
//                    Thread.sleep(10);
//                }
//            }
//        }
//        public void run() {
//            SampleSendAudioTask(videoH264FrameSender);
//        }
//    }

    public static int CHANNEL_PROFILE_BROADCASTING = 1;
    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    private String token = AgoraTest.APPID;
    private String videoFile = "test_data/send_video.h264";
    private String channelId = "";
    private String userId = "";
    private String audioFile = "test_data/send_audio_16k_1ch.pcm";
    private int sampleRate = 16000;
    private int numOfChannels = 1;
    private int height = 320;
    private int width = 640;
    private int fps = 30;
    private String localIP;
    //private boolean stringUid = false;
    private int bwe = 0;
    private AgoraLocalAudioTrack customAudioTrack;
    private AgoraLocalVideoTrack customVideoTrack;
    private PcmSender pcmSender;
    private Yuv420Sender h264Sender;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication / must");
        Option optChannelId = new Option("channelId", true, "Channel Id / must");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optAudioFile = new Option("audioFile", true, "The audio file in raw PCM format to be sent");
        Option optVideoFile = new Option("videoFile", true, "The video file in YUV420 format to be sent");
        Option optSampleRate = new Option("sampleRate", true, "Sample rate for the PCM file to be sent");
        Option optNumOfChannels = new Option("numOfChannels", true, "Number of channels for the PCM file to be sent");
        Option optFps = new Option("fps", true, "Target frame rate for sending the video stream");
        Option optBwe = new Option("bwe", true, "show or hide bandwidth estimation info");
        Option optLocalIp = new Option("localIP", true, "Local IP");
        Option optHeight = new Option("height", true, "video height");
        Option optWidth = new Option("width", true, "video width");
        //Option optStringUid = new Option("stringUid", false, "if use string uid, add this arguments");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optAudioFile);
        options.addOption(optVideoFile);
        options.addOption(optSampleRate);
        options.addOption(optNumOfChannels);
        options.addOption(optFps);
        options.addOption(optBwe);
        options.addOption(optLocalIp);
        options.addOption(optHeight);
        options.addOption(optWidth);
//        options.addOption(optStringUid);

        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        String o_videoFile = commandLine.getOptionValue("videoFile");
        System.out.println("videoFile args: "+o_videoFile);
        if (o_videoFile != null) {
            videoFile = o_videoFile;
        }
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if(o_userId != null && !o_userId.isEmpty()) userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        System.out.println("videoFile args: "+o_videoFile);
        if (o_audioFile != null) audioFile = o_audioFile;
        try {
            sampleRate = Integer.valueOf(commandLine.getOptionValue("sampleRate"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(commandLine.getOptionValue("height") != null) {
            try {
                height = Integer.valueOf(commandLine.getOptionValue("height"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if(commandLine.getOptionValue("width") != null) {
            try {
                width = Integer.valueOf(commandLine.getOptionValue("width"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            numOfChannels = Integer.valueOf(commandLine.getOptionValue("numOfChannels"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            fps = Integer.valueOf(commandLine.getOptionValue("fps"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String o_localIP = commandLine.getOptionValue("localIP");
        if (o_localIP != null) {
            localIP = o_localIP;
        }
        String o_bwe = commandLine.getOptionValue("bwe");
        if (o_bwe != null) {
            bwe = Integer.valueOf(o_bwe);
        }
        //stringUid = commandLine.hasOption("stringUid");
    }

    public static void main(String[] args) {
        YuvPcmSendTest h264PcmTest = new YuvPcmSendTest();
        h264PcmTest.handleOptions(args);
        h264PcmTest.sdkTest();
    }


    public void setup() {
        // Create Agora service
        System.out.println("videoFile :"+videoFile);
        System.out.println("audioFile :"+audioFile);
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        // Create Agora connection
        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setChannelProfile(1);
        ccfg.setClientRoleType(Constants.CLIENT_ROLE_BROADCASTER);
        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }

        GeneralTest.ConnObserver connObserver = new GeneralTest.ConnObserver();
        conn.registerObserver(connObserver);
//        if (bwe != 0) {
//            conn.registerNetworkObserver(connObserver);
//        }
        AgoraMediaNodeFactory mediaNodeFactory = service.createMediaNodeFactory();
        // Create audio data sender
        AgoraAudioPcmDataSender audioFrameSender = mediaNodeFactory.createAudioPcmDataSender();
        // Create audio track
        customAudioTrack = service.createCustomAudioTrackPcm(audioFrameSender);
        customAudioTrack.setEnabled(1);
        conn.connect(token, channelId, userId);


        // // Create video frame sender
         AgoraVideoFrameSender videoFrameSender = mediaNodeFactory.createVideoFrameSender();
        // // Create video track
        customVideoTrack = service.createCustomVideoTrackFrame(videoFrameSender);
        VideoEncoderConfig config = new VideoEncoderConfig();
        config.setCodecType(Constants.VIDEO_CODEC_H264);
        config.setDimensions(new VideoDimensions(640,360));
        config.setFrameRate(15);
        customVideoTrack.setVideoEncoderConfig(config);
        customVideoTrack.setEnabled(1);
        // Publish audio & video track
        conn.getLocalUser().publishAudio(customAudioTrack);
         conn.getLocalUser().publishVideo(customVideoTrack);

        // Wait until connected before sending media stream

        // Start sending media data
//        SendAudioThread at = new SendAudioThread(audioFrameSender);
//        // SendVideoThread vt = H264PcmTest.new SendVideoThread(videoFrameSender, exitFlag);
//        at.start();
        System.out.println("height: "+height + "  width: "+width + "  fps:"+fps);
        h264Sender = new Yuv420Sender(videoFile,1000/fps,height,width,videoFrameSender);
        pcmSender = new PcmSender(audioFile,audioFrameSender,numOfChannels,sampleRate);
        pcmSender.start();
        h264Sender.start();
    }

    public void cleanup() {
        // Unpublish audio & video track
        conn.getLocalUser().unpublishAudio(customAudioTrack);
        conn.getLocalUser().unpublishVideo(customVideoTrack);

        // Unregister connection observer
        conn.unregisterObserver();
        // conn.unregisterNetworkObserver();
        if(pcmSender != null) pcmSender.release();
        if(h264Sender != null ) h264Sender.release();
        // Disconnect from Agora channel
        int ret = conn.disconnect();
        if (ret != 0) {
            System.out.printf("conn.disconnect fail ret=%d\n", ret);
        }
        System.out.printf("Disconnected from Agora channel successfully\n");
        conn.destroy();
        // Destroy Agora Service
        service.destroy();
    }
}