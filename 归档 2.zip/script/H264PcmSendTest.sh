sh ../run.zsh ../build/io.agora.rtc.test.H264PcmSendTest -channelId  aga  -sampleRate 16000 -numOfChannels 2 -audioFile test_data/send_audio_16k_1ch.pcm -videoFile test_data/send_video.h264 -fps 15

