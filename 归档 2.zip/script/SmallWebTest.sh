sh run.zsh io.agora.rtc.test.SmallWeb
