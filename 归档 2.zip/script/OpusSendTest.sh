sh run.zsh io.agora.rtc.test.OpusSendTest -channelId  aga  -sampleRate 16000 -numOfChannels 2 -audioFile test_data/send_audio.opus 

