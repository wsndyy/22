sh run.zsh io.agora.rtc.test.StringUidSendTest -channelId aga -sampleRate 16000 -numOfChannels 1 -audioFile test_data/send_audio_16k_1ch.pcm -videoFile test_data/send_video.h264 -fps 15
