sh run.zsh io.agora.rtc.test.SendPcmByCloudProxyTest -channelId aga -sampleRate 16000 -numOfChannels 2 -enableCloudProxy 1
