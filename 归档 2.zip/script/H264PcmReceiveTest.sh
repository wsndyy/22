sh run.zsh io.agora.rtc.test.H264PcmReceiveTest -channelId  aga -sampleRate 16000 -numOfChannels 2

