#!/usr/bin/env zsh
#sh run.zsh io.agora.rtc.test.H264PcmTest -channelId  aga -token 123 -sampleRate 23900

export DYLD_LIBRARY_PATH=`pwd`/../
export LD_LIBRARY_PATH=`pwd`/../
echo "$LD_LIBRARY_PATH"
CLASS=$1
shift 1
java -cp .:third_party/commons-cli-1.5.0.jar:third_party/junit-4.13.2.jar:../build/agora-sdk.jar:./build -Xcheck:jni -XX:+HeapDumpOnOutOfMemoryError  -Djava.library.path=libs $CLASS $*
#java -cp .:third_party/commons-cli-1.5.0.jar:third_party/junit-4.13.2.jar:./agora-sdk.jar -Djava.library.path=. $CLASS $*
